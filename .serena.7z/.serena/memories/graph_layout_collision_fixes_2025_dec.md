# Graph Layout & Collision Fixes - December 2025

## Overview
Fixed multiple graph visualization issues: node overlap, variable spacing, and arrow overlap.

## Files Modified
- `static/visualizer.js`

## Key Changes

### Fix 1: Let Collision Run After Shell Positioning
**Location:** `updateSimulation()` (lines ~3423-3425)

**Problem:** Shell mode called `simulation.stop()` immediately after calculating positions, so collision forces never ran.

**Solution:** Replace `simulation.stop()` with `simulation.alpha(0.4).alphaDecay(0.08).restart()` to let collision resolve overlaps.

### Fix 2: Strengthen Collision Detection
**Location:** `createSimulation()` shell mode (lines ~1640-1653)

**Changes:**
- Collision radius: `+5px` → `+12-15px` (more padding)
- Iterations: `1` → `4` (more passes)
- Strength: `0.3` → `0.7` (stronger push)
- Alpha/decay: `0.1/0.5` → `0.4/0.08` (longer settling)

### Fix 3: Adaptive Shell Radii
**Location:** `calculateCollisionFreeRadii()` (lines ~275-300)

**Problem:** Fixed radii regardless of node count caused crowding with many nodes.

**Solution:** Calculate minimum radius based on circumference needed:
```javascript
const circumferenceNeeded = nodeCount * MIN_NODE_SPACING;
const minRadiusForCount = circumferenceNeeded / (2 * Math.PI);
radii[shell] = Math.max(baseRadius, minRadiusForCount + 20);
```

### Fix 4: Parallel Link Offset
**Location:** `calculateLinkPath()` (lines ~3864-3931)

**Problem:** Bidirectional links (A→B and B→A) drew on top of each other.

**Solution:** Detect parallel links between same nodes and offset them perpendicular to the link direction:
```javascript
const linkKey = [srcId, tgtId].sort().join('::');
const parallelLinks = links.filter(l => /* matches key */);
const parallelOffset = (linkIndex - (totalParallel - 1) / 2) * 16;
```

### Fix 5: Shell Assignment Order for Pathways
**Location:** `assignNodesToShells()` (lines ~310-408)

**Problem:** Nodes processed in random order - if interactor processed before its parent pathway, it defaulted to shell 1 instead of correct deeper shell.

**Solution:** Two-pass approach:
1. Pass 1: Sort and assign pathways by hierarchy level (parents before children)
2. Pass 2: Assign interactors (now guaranteed to have parent shell info)

### Fix 6: Adaptive Arc Span for Children
**Location:** `recalculateShellPositions()` (lines ~555-562)

**Problem:** Arc span capped at 60° regardless of child count - 6+ children in 60° = overlap.

**Solution:** Calculate arc span based on node count and shell radius:
```javascript
const minAngularSpacing = minNodeSpacing / shellRadius;
const neededArc = children.length * minAngularSpacing;
const arcSpan = Math.max(Math.PI / 6, Math.min(neededArc, Math.PI * 5 / 6)); // 30° to 150°
```

### Fix 7: Placeholder Expansion Second Layout Pass
**Location:** `handlePlaceholderClick()` (lines ~3237-3246)

**Problem:** Interactors from placeholder expansion didn't arrange with other shell nodes.

**Solution:** Added delayed second layout pass after placeholder expansion:
```javascript
setTimeout(() => {
  if (layoutMode === 'shell') {
    recalculateShellPositions();
    simulation.alpha(0.5).alphaDecay(0.05).restart();
    renderGraph();
  }
}, 100);
```

### Fix 8: Query Node for Level 2+ Mixed Content Pathways
**Location:** `expandPathwayHierarchy()` (lines ~3069-3137)

**Problem:** Level 2+ pathways with both subpathways AND interactors didn't show query protein.

**Solution:** Added query protein reference node creation in `hasMixedContent` block alongside the "X Interactors" placeholder.

### Fix 9: Hierarchical Pathway Radial Spacing
**Location:** `createSimulation()` and `updateSimulation()` radialPathways force

**Problem:** All pathway levels used same `pathwayRingRadius = 300`, causing level 1 and level 2 overlap.

**Solution:** Made radial force level-aware:
```javascript
const level = hier?.level ?? d.hierarchyLevel ?? 0;
const levelGap = 120; // Gap between hierarchy levels
const baseRadius = pathwayRingRadius + (level * levelGap);
```

Result: Level 0=300px, Level 1=420px, Level 2=540px, Level 3=660px

## Testing Checklist
- [ ] Load graph with 10+ interactors → verify no overlap
- [ ] Expand node with 6+ children → verify dynamic radius expansion
- [ ] Check bidirectional links → should see two distinct curved paths
- [ ] Expand multiple times → layout should smoothly recalculate
- [ ] Drag nodes → collision should push neighbors apart
- [ ] Click placeholder "X Interactors" → nodes should arrange in shell
- [ ] Expand level 2+ pathway with mixed content → query protein should appear
- [ ] Pathway hierarchy levels should have visible radial separation
