# Hierarchical Pathway Frontend Implementation Handoff

## Context: What Was Built (Backend Complete)

A hierarchical pathway organization system was implemented with standalone scripts that:
1. Fetch GO/KEGG ontology hierarchies
2. Build a DAG (Directed Acyclic Graph) of pathways in the database
3. Use AI (Gemini 2.5 Pro) to classify pathways and create intermediate levels
4. Assign interactions to their most specific pathways
5. Store full ancestry paths for each pathway

### Database Schema Changes (Already Implemented)

**New Table: `pathway_parents`**
- Links child pathways to parent pathways (DAG structure)
- Allows multiple parents per pathway
- Fields: `child_pathway_id`, `parent_pathway_id`, `relationship_type`, `confidence`, `source`

**Extended `pathways` Table:**
- `hierarchy_level` (INT): 0=root, higher=deeper
- `is_leaf` (BOOL): True if no child pathways
- `protein_count` (INT): Proteins in this pathway
- `ancestor_ids` (JSONB): Materialized path for fast queries

### Backend Scripts Location
All scripts are in: `scripts/pathway_hierarchy/`
- Run with: `python scripts/pathway_hierarchy/run_all.py`

---

## YOUR TASK: Frontend Implementation

### Required Changes to `static/visualizer.js`

#### 1. Nested Pathway Nodes
Currently pathways are flat violet circles. Need hierarchical expansion:
- Clicking a pathway node should show:
  - Sub-pathways (if any) as smaller pathway nodes
  - Interactors that belong directly to this pathway level
- Visual differentiation by hierarchy level (different sizes/colors per level)

#### 2. Multi-Level Expand Logic
```javascript
// Current: expandPathway() shows interactors
// Needed: expandPathway() shows sub-pathways AND/OR interactors

function expandPathway(pathwayId) {
  // 1. Check if pathway has child pathways
  // 2. If yes: show child pathway nodes
  // 3. Show interactors that are at THIS level (not deeper)
  // 4. Allow recursive expansion
}
```

#### 3. Ancestry Breadcrumb Display
When hovering/clicking a pathway, show full path:
- Example: "Cellular Signaling → Autophagy → Selective Autophagy → Aggrephagy"
- Could be tooltip or small label

#### 4. DAG Handling
A pathway can appear under multiple parents. Handle this by:
- Showing pathway in both locations when expanded
- Or showing primary location with indicator for alternate paths

### Required Changes to `app.py`

#### 1. Modify `build_full_json_from_db()`
Include hierarchy info in pathway objects:
```python
{
  "pathways": [
    {
      "id": "pathway_aggrephagy",
      "name": "Aggrephagy",
      "level": 3,
      "is_leaf": true,
      "parent_ids": ["pathway_selective_autophagy"],
      "child_pathway_ids": ["pathway_x", "pathway_y"],
      "ancestry": ["Protein Quality Control", "Autophagy", "Selective Autophagy", "Aggrephagy"],
      "interactor_ids": ["VCP", "ATXN3"],
      "interaction_count": 5
    }
  ]
}
```

#### 2. New Endpoint: `/api/pathway-tree`
Return full hierarchy tree for a protein query:
```json
{
  "tree": {
    "Cellular Signaling": {
      "level": 0,
      "children": {
        "Autophagy": {
          "level": 1,
          "children": {...},
          "interactors": ["VCP", "BECN1"]
        }
      }
    }
  }
}
```

#### 3. Pathway Expansion Endpoint
`GET /api/pathway/<pathway_id>/expand`
Returns sub-pathways and direct interactors for a pathway.

---

## Data Flow

### Current Flow (Flat)
```
Query ATXN3 → Get interactors → Each has pathways[] → Show as ring
```

### New Flow (Hierarchical)
```
Query ATXN3 → Get interactors with pathways[] containing:
  - name: "Aggrephagy"
  - hierarchy: ["Protein Quality Control", "Autophagy", "Selective Autophagy", "Aggrephagy"]
  - level: 3
  - is_leaf: true

→ Build nested pathway structure
→ Show top-level pathways initially
→ Expand on click to reveal sub-pathways/interactors
```

---

## Key Files to Read

1. **`models.py`** (lines 158-330): `Pathway`, `PathwayParent` models
2. **`app.py`** (function `build_full_json_from_db`): Current JSON building logic
3. **`static/visualizer.js`** (lines 550-700): Current pathway rendering
4. **`scripts/pathway_hierarchy/dag_models.py`**: PathwayDAG class for reference

---

## Example Transformation

### Before (User sees flat pathways):
```
ATXN3 query shows:
├── Protein Quality Control (violet node)
├── Autophagy (violet node)
├── Cell Death (violet node)
└── Clicking any shows interactors directly
```

### After (User sees hierarchical):
```
ATXN3 query shows:
├── Protein Quality Control (click to expand)
│   ├── Autophagy (click to expand)
│   │   ├── Selective Autophagy (click to expand)
│   │   │   ├── Aggrephagy ← VCP, ATXN3 interactors here
│   │   │   └── Mitophagy ← PINK1 interactor here
│   │   └── Macroautophagy
│   └── Ubiquitin-Proteasome System
└── Cell Death
    └── Apoptosis ← CASP3 interactor here
```

---

## Visual Design Suggestions

### Pathway Node Sizing by Level
- Level 0 (root): radius 50px
- Level 1: radius 45px
- Level 2: radius 40px
- Level 3+: radius 35px

### Color Gradient by Level
- Level 0: Deep violet (#7c3aed)
- Level 1: Medium violet (#8b5cf6)
- Level 2: Light violet (#a78bfa)
- Level 3+: Pale violet (#c4b5fd)

### Expand/Collapse Indicators
- Collapsed pathway with children: small "+" icon
- Expanded pathway: small "-" icon
- Leaf pathway (no children): no icon

---

## Critical Invariants to Preserve

1. **Node IDs**: Pathways use `pathway_${name}` format
2. **Link IDs**: `${src}-${tgt}` for pathway-interactor links
3. **Force simulation**: Adjust forces for nested layout
4. **Modal behavior**: Clicking interactors still opens modal
5. **Existing interactor rendering**: Don't break non-pathway features

---

## Testing Checklist

- [ ] Expand root pathway → see sub-pathways
- [ ] Expand sub-pathway → see deeper levels
- [ ] Reach leaf pathway → see interactors
- [ ] Collapse pathway → hide children
- [ ] Multiple parents: pathway appears correctly
- [ ] Ancestry breadcrumb shows on hover
- [ ] Performance: handles 50+ pathways smoothly
- [ ] Mobile: touch-friendly expansion
