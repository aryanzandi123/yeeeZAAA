# Pathway Hierarchy Fix - Handoff Document

## Current Task Status
**Fixing AI pathway hierarchy creation (Option B)** - Plan complete, implementation NOT started.

## The Problem

### Issue 1: Hierarchy Structure Bug
AI-created pathways appear as ROOT (level 0) instead of properly nested:
```
WRONG:
├── Transcription (level 0 - ROOT)
├── Epigenetic Regulation (level 0 - ROOT)  
├── Histone Deacetylation (level 0 - ROOT)

CORRECT:
└── Cellular Signaling (level 0 - ROOT)
    └── Transcription (level 1)
        └── Epigenetic Regulation (level 2)
            └── Histone Deacetylation (level 3 - LEAF)
                └── ATXN3-HDAC3, ATXN3-CBP (interactions)
```

### Issue 2: Function Pathway Mismatch
Modal shows `[Pathway = Transcription]` for function, but interaction is under "Histone Deacetylation"

## Root Causes Identified

1. **`create_intermediate_pathway()`** in `04_ai_create_missing_branches.py` doesn't set `hierarchy_level` (defaults to 0)
2. **AI prompts** don't ask for full parent hierarchy chain
3. **Hardcoded fallback** to "Cellular Signaling" fails silently
4. **Functions** have their own `pathway` field not synced with interaction pathway

## Files to Modify

| File | Change |
|------|--------|
| `scripts/pathway_hierarchy/04_ai_create_missing_branches.py` | Fix `create_intermediate_pathway()`, add `ensure_hierarchy_chain()` |
| `scripts/pathway_hierarchy/ai_hierarchy_builder.py` | Update prompts to require full hierarchy chain |
| `scripts/pathway_hierarchy/03_classify_existing_pathways.py` | Process hierarchy chains from AI response |
| `scripts/pathway_hierarchy/05_assign_interactions_to_leaves.py` | Also update function pathways |

## Implementation Steps

### Step 1: Fix `create_intermediate_pathway()` 
File: `scripts/pathway_hierarchy/04_ai_create_missing_branches.py` (lines 137-156)

Add `parent_id` parameter, calculate `hierarchy_level` from parent:
```python
def create_intermediate_pathway(session, name, description, parent_id=None, go_id=None):
    # Calculate hierarchy_level = parent.hierarchy_level + 1
    # Create parent link if parent_id provided
```

### Step 2: Add `ensure_hierarchy_chain()` function
Same file. Takes chain like `["Cellular Signaling", "Transcription", "Epigenetic Regulation", "Histone Deacetylation"]` and ensures all exist with proper parent-child links.

### Step 3: Update AI prompts
File: `scripts/pathway_hierarchy/ai_hierarchy_builder.py`

Update `HANDLE_ORPHAN_PROMPT` to require response format:
```json
{
  "pathway_name": {
    "hierarchy_chain": ["Root", "Level1", "Level2", "ThisPathway"],
    "confidence": 0.85,
    "reasoning": "..."
  }
}
```

### Step 4: Process hierarchy chains in Scripts 03/04
Call `ensure_hierarchy_chain()` when AI returns hierarchy_chain

### Step 5: Sync function pathways
File: `scripts/pathway_hierarchy/05_assign_interactions_to_leaves.py`

In `update_interaction_jsonb_pathways()`, also update each function's `pathway` field to match the most specific pathway.

## Frontend Changes (ALREADY DONE)
These were implemented earlier in the session:
- ✅ `pathwayToInteractions` Map in `visualizer.js`
- ✅ `expandPathwayWithInteractions()` function
- ✅ `interaction-edge` link type handling
- ✅ CSS styles for interaction edges in `viz-styles.css`
- ✅ Backend `build_full_json_from_db()` includes `interactions[]` array per pathway

## Key Context

### ROOT_CATEGORIES (from Script 02)
- Cellular Signaling
- Metabolism
- Protein Quality Control
- Cell Death
- Cell Cycle
- DNA Damage Response
- Vesicle Transport
- Immune Response
- Neuronal Function
- Cytoskeleton Organization

### User's Decision
- **Option B chosen**: Fix AI classification logic (not manually add to base hierarchy)
- **Transcription should nest under Cellular Signaling**, not be a new ROOT

## Verification After Implementation

1. Clear pathway tables:
```sql
DELETE FROM pathway_parents;
DELETE FROM pathway_interactions;
DELETE FROM pathways;
```

2. Run full pipeline:
```bash
python scripts/pathway_hierarchy/run_all.py
```

3. Query to verify hierarchy:
```sql
SELECT p.name, p.hierarchy_level, pp.parent_pathway_id
FROM pathways p
LEFT JOIN pathway_parents pp ON p.id = pp.child_pathway_id
ORDER BY p.hierarchy_level;
```

## Plan File Location
Full detailed plan: `C:\Users\aryan\.claude\plans\clever-bubbling-hummingbird.md`
