# Pathway Config Refactor - Complete Handoff

## QUICK START
```
Activate the current dir as project using serena
Read the memory file pathway_config_refactor_handoff.md
Continue implementation from where we left off
```

---

## PROBLEM SUMMARY

After running `python scripts/pathway_hierarchy/run_all.py`, only 1 root pathway shows in visualization instead of multiple. The issues are:

1. **Disconnected data flow**: `build_full_json_from_db()` in app.py reads pathways from stale JSONB instead of database tables
2. **Duplicate pathways**: "NF-kB Signaling" vs "NF-κB Signaling Pathway" treated as different
3. **ROOT_CATEGORIES hardcoded in 5+ files**: Adding new roots requires editing 5 files
4. **Poor hierarchy structure**: NHEJ appears at both level 1 and level 3

---

## CHANGES ALREADY COMPLETED ✅

### 1. app.py - build_full_json_from_db() (lines 829-997)
**Status: DONE**
- Rewrote to query `PathwayInteraction`, `Pathway`, `PathwayParent` tables
- Always includes all root pathways (hierarchy_level=0)
- No longer reads from stale interaction.data.pathways JSONB

### 2. hierarchy_utils.py - normalize_pathway_name() (lines 263-322)
**Status: DONE**
- Enhanced to handle Greek characters (κ→k, β→beta, α→alpha, γ→gamma)
- Removes hyphens between alphanumeric chars (NF-kB → NFkB)
- Strips multiple suffixes repeatedly

### 3. 07_merge_duplicate_pathways.py
**Status: DONE - NEW FILE CREATED**
- Path: `scripts/pathway_hierarchy/07_merge_duplicate_pathways.py`
- Finds and merges duplicate pathways based on normalized names
- Run with `--dry-run` to preview

### 4. 02_build_base_hierarchy.py - SUB_CATEGORIES fix (lines 151-167)
**Status: DONE**
- Fixed DNA Damage Response hierarchy:
  - DNA Damage Response → DNA Repair, DNA Damage Checkpoint
  - DNA Repair → Double-Strand Break Repair, NER, BER, Mismatch Repair
  - Double-Strand Break Repair → HR, NHEJ (moved from level 1 to level 3)

---

## CHANGES COMPLETED ✅ (Updated 2025-12-05)

### 1. CREATE: pathway_config.py (NEW FILE)
**Path:** `scripts/pathway_hierarchy/pathway_config.py`

```python
"""
Pathway Hierarchy Configuration
================================
Central config for ROOT_CATEGORIES and SUB_CATEGORIES.
Edit this file to add new pathways - all scripts will pick up changes.
"""

# Root categories (hierarchy_level = 0)
ROOT_CATEGORIES = [
    {"name": "Cellular Signaling", "go_id": "GO:0007165", "description": "Signal transduction pathways"},
    {"name": "Metabolism", "go_id": "GO:0008152", "description": "Metabolic processes"},
    {"name": "Protein Quality Control", "go_id": "GO:0006457", "description": "Protein folding/degradation"},
    {"name": "Cell Death", "go_id": "GO:0008219", "description": "Apoptosis, necroptosis, etc."},
    {"name": "Cell Cycle", "go_id": "GO:0007049", "description": "Cell division control"},
    {"name": "DNA Damage Response", "go_id": "GO:0006974", "description": "DNA repair and genomic stability"},
    {"name": "Vesicle Transport", "go_id": "GO:0016192", "description": "Intracellular trafficking"},
    {"name": "Immune Response", "go_id": "GO:0006955", "description": "Innate and adaptive immunity"},
    {"name": "Neuronal Function", "go_id": "GO:0050877", "description": "Nervous system processes"},
    {"name": "Cytoskeleton Organization", "go_id": "GO:0007015", "description": "Actin/microtubule dynamics"},
    # === ADD NEW ROOTS BELOW ===
    # {"name": "Gene Expression", "go_id": "GO:0010467", "description": "Transcription and translation"},
    # {"name": "RNA Processing", "go_id": "GO:0006396", "description": "RNA splicing, editing, decay"},
]

# Convenience set for validation (auto-generated)
ROOT_CATEGORY_NAMES = {cat["name"] for cat in ROOT_CATEGORIES}

# Sub-categories organized by parent pathway name
# IMPORTANT: Copy FULL SUB_CATEGORIES dict from 02_build_base_hierarchy.py
SUB_CATEGORIES = {
    # ... copy all from 02_build_base_hierarchy.py
}
```

### 2. UPDATE: 02_build_base_hierarchy.py
- Remove local ROOT_CATEGORIES and SUB_CATEGORIES
- Add import: `from scripts.pathway_hierarchy.pathway_config import ROOT_CATEGORIES, SUB_CATEGORIES`

### 3. UPDATE: 03_classify_existing_pathways.py
- Find local ROOT_CATEGORIES set (around line 51-60)
- Replace with: `from scripts.pathway_hierarchy.pathway_config import ROOT_CATEGORY_NAMES`
- Use `ROOT_CATEGORY_NAMES` instead of local `ROOT_CATEGORIES`

### 4. UPDATE: 04_ai_create_missing_branches.py
- Find local ROOT_CATEGORIES set (around line 243-250)
- Replace with: `from scripts.pathway_hierarchy.pathway_config import ROOT_CATEGORY_NAMES`

### 5. UPDATE: 05_assign_interactions_to_leaves.py
- Find local ROOT_CATEGORIES set (around line 44-50)
- Replace with: `from scripts.pathway_hierarchy.pathway_config import ROOT_CATEGORY_NAMES`

### 6. UPDATE: ai_hierarchy_builder.py
- Find ROOT_CATEGORIES references in prompts
- Import and use `ROOT_CATEGORY_NAMES` from config

---

## FILES QUICK REFERENCE

| File | Status | Action |
|------|--------|--------|
| `app.py` (829-997) | ✅ DONE | Pathway query rewritten |
| `hierarchy_utils.py` (263-322) | ✅ DONE | normalize_pathway_name enhanced |
| `07_merge_duplicate_pathways.py` | ✅ DONE | New file created |
| `02_build_base_hierarchy.py` (151-167) | ✅ DONE | SUB_CATEGORIES fixed |
| `pathway_config.py` | ❌ TODO | Create new config file |
| `02_build_base_hierarchy.py` | ❌ TODO | Import from config |
| `03_classify_existing_pathways.py` | ❌ TODO | Import ROOT_CATEGORY_NAMES |
| `04_ai_create_missing_branches.py` | ❌ TODO | Import ROOT_CATEGORY_NAMES |
| `05_assign_interactions_to_leaves.py` | ❌ TODO | Import ROOT_CATEGORY_NAMES |
| `ai_hierarchy_builder.py` | ❌ TODO | Import ROOT_CATEGORY_NAMES |

---

## EXECUTION ORDER (After Implementation)

```bash
# 1. Clear pathway tables
python scripts/clear_pathway_tables.py

# 2. Delete cache files (Windows)
del /Q cache\*.json cache\pruned\*.json cache\hierarchy_reports\*

# 3. Start app and query protein
python app.py
# Visit http://localhost:5000 and query VCP

# 4. Run hierarchy pipeline
python scripts/pathway_hierarchy/run_all.py

# 5. (Optional) Merge duplicates
python scripts/pathway_hierarchy/07_merge_duplicate_pathways.py

# 6. View visualization
# http://localhost:5000/api/visualize/VCP
```

---

## EXPECTED OUTCOME

- Console: `🌳 Found N root pathways (of M total)` (N = configured roots)
- All root categories appear in sidebar
- No duplicate pathway names
- Proper hierarchy depth
- Easy to add new roots by editing ONE file (pathway_config.py)

---

## USER'S LONG-TERM VISION

The user aims to build a comprehensive pathway database covering ALL known cellular pathways, organized from level 0 (root) down to the most specific leaf pathways. The configurable approach enables this by making it easy to add new roots and sub-categories over time.
