# Pathway Layout Fix - Partial Implementation (Dec 2025)

## Problem
Expanding multiple pathways created chaos: duplicate proteins, disconnected clusters, random pathway positions.

## What Was Implemented ✅

### Reference Nodes (A1-A3)
- `findExistingInteractorNode(symbol)` - checks if protein exists (L2042-2052)
- `navigateToPrimaryNode(refNode)` + `pulseNode(nodeId)` - click nav (L2054-2097)
- Modified `expandPathway()` L1441-1517 - creates `ref_${symbol}@${pathwayId}` nodes
- Modified `expandPathwayWithInteractions()` L1714-2013 - same for all direction groups
- `handleNodeClick()` L3541-3545 - routes reference clicks to navigation
- CSS `.reference-node` styles in viz-styles.css L1355-1388

### Force Tuning (C1-C3)
- Collision: pathway 55px, interactor +6px, reference +3px (L1081-1088)
- Charge: pathway -350, interactor -200, reference -100 (L1071-1076)
- Link distance: pathway-interactor 120/80px (L1044-1052)
- Orbit strength: 0.6 (L1134)

### Tighter Clusters (B2)
- `calculateExpandRadius()` L65-82: minRadius 90px, maxRadius 180px, 16px gap

### Collapse Behavior
- `collapsePathway()` L2097-2125 - always removes ALL nodes with `pathwayId`

## Implementation Complete ✅ (Dec 2025)

### B1: Pathway Sector Assignment ✅
Added `_targetAngle: pos.angle` to all 6 node creation blocks in `expandPathwayWithInteractions()`:
- Upstream ref nodes (L1831)
- Upstream regular nodes (L1857)
- Downstream ref nodes (L1912)
- Downstream regular nodes (L1938)
- Bidirectional ref nodes (L1992)
- Bidirectional regular nodes (L2018)

### B3: Concentric Ring Layout ✅
Already implemented via:
- `pathwayRingRadius = 300` (pathway nodes)
- `forceRadialPathways` keeps pathways at 300/380px from center
- `forcePathwayOrbit` keeps interactors orbiting their parent at `expandRadius`

### B4: forceSectorConstraint() ✅
Added new custom D3 force (L217-252):
```javascript
function forceSectorConstraint() {
  // Pulls pathway interactors toward their sector around parent pathway
  // Uses node._targetAngle and node.expandRadius
}
```
Registered in simulation (L1180): `.force('sectorConstraint', forceSectorConstraint().strength(0.35))`

### D3: Reference Link Styling ✅
- Added `refClass` check in `renderGraph()` (L2593-2595)
- Added `.link-reference` CSS in viz-styles.css (L1568-1577):
  - `stroke-dasharray: 4, 2`
  - `opacity: 0.55`

### D4: Cluster Highlighting on Hover ✅
Added helper functions (L312-358):
- `highlightCluster(pathwayId)` - highlights nodes/links with matching `_pathwayContext`
- `clearClusterHighlight()` - resets to normal state

Added hover handlers:
- Interactor circles (L2879-2884): mouseenter/mouseleave call highlight functions
- Pathway rects (L2774-2783): integrated with ancestry tooltip handlers
