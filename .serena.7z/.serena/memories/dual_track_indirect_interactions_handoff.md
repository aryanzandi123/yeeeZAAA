# Dual-Track Indirect Interactions Implementation - Session Handoff

## STATUS: 75% Complete - Modal & Graph Rendering Remaining

### Quick Context
- **Goal:** Display BOTH indirect (NET effect) and direct (DIRECT link) interactions separately
- **Example:** For ATXN3→VCP→UFD1 chain:
  - Row 1: ATXN3→UFD1 [NET EFFECT] - shows NET chain effects
  - Row 2: VCP→UFD1 [DIRECT LINK] - shows pair-specific DIRECT effects
- **User Requirement:** "For UFD1, show VCP→UFD1 (direct) NOT ATXN3→UFD1 (net)"

---

## ✅ COMPLETED WORK (Verified Line Numbers)

### Backend (100% Complete)

#### 1. scripts/validate_existing_arrows.py

**Helper Functions Added:**
- Line 120: `extract_direct_link_evidence()` - Finds papers mentioning mediator→target
- Line 162: `build_direct_mediator_link()` - Constructs direct link data structure  
- Line 206: `process_indirect_interaction()` - Main orchestrator for extraction

**Dual Validation System:**
- **Phase 1** (existing): Validates indirect interactions with NET effects
  - Marks with `function_context="net"` (line 441)
  - Stores in database as indirect interaction
  
- **Phase 2** (NEW, lines 771-910): Extracts direct mediator links
  - Line 785: "PHASE 2: EXTRACTING DIRECT MEDIATOR LINKS" header
  - Checks for evidence of mediator→target relationship
  - If evidence found: validates independently (line 809-813)
  - Creates new database record with `function_context="direct"` (line 855)
  - Handles canonical ordering (lines 860-894)

**Database Differentiation** (lines 436-444):
```python
if interaction_type == "indirect":
    data["function_context"] = "net"  # NET effects through full chain
elif not data.get("function_context"):
    data["function_context"] = "direct"  # Default for direct
```

**Key Logic Flow:**
1. Extract interaction data from database
2. Validate indirect interaction (ATXN3→UFD1) → NET functions
3. Check if indirect (line 784)
4. Call `process_indirect_interaction()` → extracts VCP→UFD1
5. Validate VCP→UFD1 independently → DIRECT functions
6. Create new database record for VCP→UFD1
7. Both records coexist with different `function_context`

#### 2. app.py - build_full_json_from_db (Lines 568-577)

**JSON Builder Enhancements:**
```python
# Add differentiation flags for dual-track indirect/direct system
function_context = interaction_data.get("function_context")
if function_context == "net":
    interaction_data["_net_effect"] = True  # Frontend marker
    interaction_data["_display_badge"] = "NET EFFECT"
elif function_context == "direct" and interaction_data.get("_inferred_from_chain"):
    interaction_data["_direct_mediator_link"] = True  # Frontend marker
    interaction_data["_display_badge"] = "DIRECT LINK"
```

**Effect Labels** (lines 525-566):
- Auto-generates `interaction_effect` from `arrow`
- Auto-generates `function_effect` for each function
- For indirect with `arrow_context`: adds `net_effect` and `direct_effect`

### Frontend (75% Complete)

#### 3. static/styles.css (Lines 592-682)

**Badge Styles:**
```css
.context-badge.net {
    background: #f59e0b;  /* Amber for NET effects */
    color: white;
}

.context-badge.direct {
    background: #10b981;  /* Green for DIRECT links */
    color: white;
}
```

**Table Row Differentiation:**
```css
.table-row.net-effect {
    background: rgba(245, 158, 11, 0.05);
    border-left: 3px solid #f59e0b;
}

.table-row.direct-link {
    background: rgba(16, 185, 129, 0.05);
    border-left: 3px solid #10b981;
}
```

**Modal Function Sections:**
```css
.function-section.net-effects {
    border-color: #f59e0b;
    background: rgba(245, 158, 11, 0.05);
}

.function-section.direct-effects {
    border-color: #10b981;
    background: rgba(16, 185, 129, 0.05);
}
```

**Dark mode support included** (lines 667-682)

#### 4. static/visualizer.js - Table View

**collectFunctionEntries() Enhancement (Lines 5769-5813):**
```javascript
// Detect function context for dual-track system
const functionContext = fn.function_context || L.function_context || null;
const isNetEffect = L._net_effect || functionContext === 'net';
const isDirectLink = L._direct_mediator_link || functionContext === 'direct';
const displayBadge = L._display_badge || null;

// Add to entry object
entries.push({
    // ... other fields ...
    functionContext: functionContext,
    isNetEffect: isNetEffect,
    isDirectLink: isDirectLink,
    displayBadge: displayBadge
});
```

**buildTableView() Enhancement (Lines 5599-5667):**
```javascript
// Add context-specific CSS classes
let rowClasses = ['function-row'];
if (entry.isNetEffect) {
    rowClasses.push('net-effect');
} else if (entry.isDirectLink) {
    rowClasses.push('direct-link');
}
row.className = rowClasses.join(' ');

// Generate context badge HTML
let contextBadgeHtml = '';
if (entry.isNetEffect && entry.displayBadge) {
    contextBadgeHtml = `<span class="context-badge net">${escapeHtml(entry.displayBadge)}</span>`;
} else if (entry.isDirectLink && entry.displayBadge) {
    contextBadgeHtml = `<span class="context-badge direct">${escapeHtml(entry.displayBadge)}</span>`;
}

// Render badge inline with interaction text
row.innerHTML = `
    ...
    ${escapeHtml(displaySource)}
    <span class="interaction-arrow ${arrowColorClass}">${arrowSymbol}</span>
    ${escapeHtml(displayTarget)}
    ${contextBadgeHtml}
    ...
`;
```

---

## ⏳ REMAINING WORK (2 Tasks - ~80 Lines Total)

### Task 1: Modal Function Grouping (~50 lines)

**File:** `static/visualizer.js`
**Location:** `showInteractionModal()` function (around lines 2134-2300)
**Current State:** Renders all functions in one list
**Needed:** Group by context and render in separate sections

**Implementation Steps:**

1. **Find the function rendering section** (around line 2134)
   - Look for where `functionsHTML` is built
   - Current code renders all functions together

2. **Add grouping logic BEFORE rendering:**
```javascript
// Group functions by context
const netFunctions = [];
const directFunctions = [];
const legacyFunctions = [];  // No context (backward compatibility)

functions.forEach(f => {
    const ctx = f.function_context;
    if (ctx === 'net' || (L._net_effect && !ctx)) {
        netFunctions.push(f);
    } else if (ctx === 'direct' || (L._direct_mediator_link && !ctx)) {
        directFunctions.push(f);
    } else {
        legacyFunctions.push(f);
    }
});
```

3. **Replace existing functionsHTML rendering with:**
```javascript
let functionsHTML = '';

// NET EFFECT Section
if (netFunctions.length > 0) {
    functionsHTML += `
        <div class="function-section net-effects">
            <div class="function-section-header">
                Net Effect (via chain) <span class="context-badge net">NET</span>
            </div>
            <div class="functions-list">
                ${netFunctions.map(f => {
                    const effectArrow = f.arrow || 'complex';
                    return renderExpandableFunction(f, functionSourceProtein, functionTargetProtein, effectArrow);
                }).join('')}
            </div>
        </div>
    `;
}

// DIRECT INTERACTION Section
if (directFunctions.length > 0) {
    functionsHTML += `
        <div class="function-section direct-effects">
            <div class="function-section-header">
                Direct Interaction <span class="context-badge direct">DIRECT</span>
            </div>
            <div class="functions-list">
                ${directFunctions.map(f => {
                    const effectArrow = f.arrow || 'complex';
                    return renderExpandableFunction(f, functionSourceProtein, functionTargetProtein, effectArrow);
                }).join('')}
            </div>
        </div>
    `;
}

// Legacy (no context) - render as-is for backward compatibility
if (legacyFunctions.length > 0 && netFunctions.length === 0 && directFunctions.length === 0) {
    // Use existing rendering logic for backward compatibility
    functionsHTML += renderAllFunctions(legacyFunctions);
}
```

4. **Key Points:**
   - Use `functionSourceProtein` and `functionTargetProtein` (already defined in modal)
   - Preserve existing `renderExpandableFunction()` call structure
   - CSS classes already defined (`.function-section.net-effects`, etc.)
   - Badges will render with existing styles

---

### Task 2: Graph Link Visual Differentiation (~30 lines)

**File:** `static/visualizer.js`
**Location:** D3 link rendering section (around lines 1200-1400)
**Current State:** All links render with same styling
**Needed:** Different colors and dash patterns for NET vs DIRECT

**Implementation Steps:**

1. **Find link key generation** (prevents duplicate links):
```javascript
// Current (around line 1300):
const linkKey = `${source.id}-${target.id}`;

// Update to include context:
const getFunctionContext = d => {
    if (d._net_effect || d.function_context === 'net') return 'net';
    if (d._direct_mediator_link || d.function_context === 'direct') return 'direct';
    return 'normal';
};

const functionContext = getFunctionContext(d);
const linkKey = `${source.id}-${target.id}-${functionContext}`;
```

2. **Find link stroke styling** (around line 1350):
```javascript
// Update stroke color
.style('stroke', d => {
    const ctx = getFunctionContext(d);
    if (ctx === 'net') return '#f59e0b';  // Amber for NET
    if (ctx === 'direct') return '#10b981';  // Green for DIRECT
    
    // Default colors based on arrow type
    if (d.arrow === 'activates') return '#059669';
    if (d.arrow === 'inhibits') return '#dc2626';
    return '#6b7280';  // Default gray
})
```

3. **Add dash pattern** (right after stroke color):
```javascript
.style('stroke-dasharray', d => {
    const ctx = getFunctionContext(d);
    if (ctx === 'net') return '5,5';  // Dashed for NET effects
    return null;  // Solid for DIRECT and normal
})
```

4. **Add context to tooltip** (find `.append('title')` section):
```javascript
linkElements.append('title')
    .text(d => {
        const ctx = getFunctionContext(d);
        let contextLabel = '';
        if (ctx === 'net') contextLabel = ' [NET EFFECT]';
        if (ctx === 'direct') contextLabel = ' [DIRECT LINK]';
        
        const arrow = d.arrow || 'binds';
        return `${d.source.id} ${arrow} ${d.target.id}${contextLabel}`;
    });
```

5. **Verify link data structure:**
   - Links come from `links` array populated by graph data
   - Each link should have `_net_effect` or `_direct_mediator_link` flags
   - Both NET and DIRECT links for same protein pair should render separately

**Key Points:**
- NET links: Amber (#f59e0b) + dashed (5,5)
- DIRECT links: Green (#10b981) + solid
- Both render without overlap due to different link keys
- Tooltips show context for clarity

---

## 🧪 TESTING CHECKLIST

### Pre-Testing: Verify Data Flow

**1. Check validate_existing_arrows.py has all functions:**
```bash
grep -n "def extract_direct_link_evidence" scripts/validate_existing_arrows.py
grep -n "PHASE 2: EXTRACTING DIRECT MEDIATOR LINKS" scripts/validate_existing_arrows.py
grep -n "function_context.*net" scripts/validate_existing_arrows.py
```

**Expected:**
- Line ~120: extract_direct_link_evidence
- Line ~785: PHASE 2 header
- Line ~441: function_context assignment

### Backend Testing

**1. Run validation:**
```bash
python scripts/validate_existing_arrows.py --protein ATXN3 --dry-run --verbose
```

**Expected output:**
```
PHASE 1: VALIDATION
  [1/N] ✓ ATXN3 → VCP → UFD1: X correction(s)
  ...

PHASE 2: EXTRACTING DIRECT MEDIATOR LINKS
  [INFO] Found Y indirect interactions with extractable direct links
  
  [1/Y] Validating direct link: VCP → UFD1
    → Evidence found for VCP→UFD1 direct interaction
    → Creating new direct link in database
    → Created direct link successfully (ID: Z)
    
[PHASE 2 COMPLETE]
  Direct links extracted: Y
  Direct links validated: Y
  New direct links created: Y
```

**2. Check database:**
```sql
-- Should show BOTH records:
SELECT 
    id, 
    data->>'function_context' as context,
    interaction_type,
    data->>'_inferred_from_chain' as inferred
FROM interactions
WHERE protein_a_id = (SELECT id FROM proteins WHERE symbol = 'VCP')
   OR protein_b_id = (SELECT id FROM proteins WHERE symbol = 'VCP');
```

**Expected:**
- ATXN3↔UFD1: `context='net'`, `interaction_type='indirect'`, `inferred=NULL`
- VCP↔UFD1: `context='direct'`, `interaction_type='direct'`, `inferred='true'`

### Frontend Testing

**1. Table View (Already works):**
- [ ] Visit: `http://localhost:5000/api/visualize/ATXN3`
- [ ] Switch to table view
- [ ] Look for UFD1 interactions
- [ ] Should see TWO rows:
  - Row 1: ATXN3 → UFD1 (via VCP) with amber [NET EFFECT] badge
  - Row 2: VCP → UFD1 with green [DIRECT LINK] badge
- [ ] Check row backgrounds (amber tint vs green tint)
- [ ] Verify no visual overlap

**2. Modal View (NEEDS IMPLEMENTATION):**
- [ ] Click on UFD1 row in table
- [ ] Modal should show TWO sections:
  - "Net Effect (via chain)" with amber badge and border
  - "Direct Interaction" with green badge and border
- [ ] Each section has its own functions
- [ ] Functions in NET section show chain context
- [ ] Functions in DIRECT section show pair context

**3. Graph View (NEEDS IMPLEMENTATION):**
- [ ] View graph visualization
- [ ] Look for ATXN3-UFD1 link
- [ ] Should see TWO links:
  - Amber dashed line (NET)
  - Green solid line (DIRECT)
- [ ] Hover over each link → tooltip shows context
- [ ] Click link → opens correct modal
- [ ] Verify no visual overlap in force layout

### Edge Cases

- [ ] **Legacy data (no function_context):** Still renders normally
- [ ] **Direct interaction (not extracted):** Shows as normal, no badge
- [ ] **Expand/collapse:** Both links collapse independently
- [ ] **Search/filter:** Works for both NET and DIRECT rows
- [ ] **Dark mode:** Badges and backgrounds render correctly

---

## 📂 FILES MODIFIED (With Line Numbers)

1. **scripts/validate_existing_arrows.py**
   - Lines 120-274: Helper functions
   - Lines 436-444: Function context assignment
   - Lines 771-910: Phase 2 validation

2. **app.py**
   - Lines 525-566: Effect label generation
   - Lines 568-577: Differentiation flags

3. **static/styles.css**
   - Lines 592-682: Badge and section styling

4. **static/visualizer.js**
   - Lines 5769-5813: collectFunctionEntries context detection
   - Lines 5599-5667: buildTableView badge rendering
   - Lines ~2134-2300: **TODO** - Modal grouping
   - Lines ~1200-1400: **TODO** - Graph styling

---

## 🔑 KEY CONCEPTS

### Function Context Values
- `"net"` = NET effect through full chain (ATXN3→VCP→UFD1)
- `"direct"` = DIRECT pair-specific effect (VCP→UFD1)
- `null`/`undefined` = Legacy data (no context)

### Differentiation Flags (Frontend Markers)
- `_net_effect: true` = Indirect interaction with NET functions
- `_direct_mediator_link: true` = Extracted direct link with DIRECT functions
- `_display_badge` = "NET EFFECT" or "DIRECT LINK" text for rendering

### Data Flow
```
Database (function_context field)
  ↓
build_full_json_from_db() (adds flags)
  ↓
JSON embedded in HTML (_net_effect, _direct_mediator_link)
  ↓
Table: collectFunctionEntries() → detectscontext → renders badges ✅
  ↓
Modals: showInteractionModal() → groups by context → separate sections ⏳
  ↓
Graph: D3 rendering → styles by context → amber/green + dash/solid ⏳
```

---

## 🚀 NEXT STEPS FOR NEW SESSION

### Activation Command
```
Read the memory file: dual_track_indirect_interactions_handoff
```

### Immediate Actions

1. **Verify validate_existing_arrows.py (5 min):**
   ```bash
   grep -n "PHASE 2: EXTRACTING DIRECT MEDIATOR LINKS" scripts/validate_existing_arrows.py
   ```
   - Should return line ~785
   - Confirms all backend changes are saved

2. **Update showInteractionModal() in visualizer.js (30 min):**
   - Find function around line 2134
   - Add function grouping by context
   - Render NET and DIRECT sections separately
   - Test modal displays both sections with badges

3. **Update D3 link rendering in visualizer.js (20 min):**
   - Find link rendering around line 1200-1400
   - Add context to link keys
   - Apply amber/dashed for NET, green/solid for DIRECT
   - Test graph shows both links

4. **Full system test (30 min):**
   - Run validation on ATXN3
   - Check database has both records
   - Verify table shows two rows with badges
   - Verify modal shows two sections
   - Verify graph shows two links
   - Test all interactions work correctly

**Total estimated time: 1.5 hours**

---

## 💡 IMPORTANT NOTES

### What Works Now
- ✅ Backend dual validation (Phase 1 + Phase 2)
- ✅ Database stores both NET and DIRECT records
- ✅ JSON builder adds differentiation flags
- ✅ CSS styling defined and ready
- ✅ Table view renders badges and row styling

### What Needs Work
- ⏳ Modal function grouping (showInteractionModal)
- ⏳ Graph link visual differentiation (D3 rendering)

### Why Table Works But Modals Don't
- Table reads from `links` array which is live-updated
- Modal reads from embedded JSON (baked at page load)
- **SOLUTION:** Modal needs to group functions by `function_context` field
- The data is ALREADY THERE in the JSON, just needs grouping logic

---

## 🔍 DEBUGGING TIPS

### If direct links don't appear in database:

1. **Check Phase 2 execution:**
   ```bash
   python scripts/validate_existing_arrows.py --protein ATXN3 --verbose
   # Look for "PHASE 2: EXTRACTING DIRECT MEDIATOR LINKS"
   ```

2. **Check if evidence was found:**
   ```
   # Output should show:
   [1/Y] Validating direct link: VCP → UFD1
     → Evidence found for VCP→UFD1 direct interaction
   ```

3. **If "No evidence found":**
   - Check `extract_direct_link_evidence()` logic (line 120-159)
   - Verify papers mention both mediator AND target in title/quote
   - May need to adjust evidence extraction heuristics

4. **Query database directly:**
   ```sql
   SELECT id, data->>'function_context', data->>'_inferred_from_chain'
   FROM interactions
   WHERE data->>'function_context' = 'direct';
   ```

### If badges don't render:

1. **Check JSON has flags:**
   - View page source
   - Search for `_net_effect` and `_direct_mediator_link`
   - Should appear in embedded JSON

2. **Check collectFunctionEntries():**
   - Add console.log in line 5773:
   ```javascript
   console.log('Context detected:', functionContext, isNetEffect, isDirectLink);
   ```

3. **Check CSS loaded:**
   - Inspect element in browser
   - Verify `.context-badge.net` styles are present
   - Check for CSS conflicts

### If modal doesn't group:

1. **This is EXPECTED** - modal grouping not yet implemented
2. **Follow Task 1 instructions** to add grouping logic
3. **Test by:** Check if functions have `function_context` field
   ```javascript
   console.log('Functions:', functions.map(f => f.function_context));
   ```

---

## 📞 USER REQUIREMENTS RECAP

**Original Request:**
> "For UFD1, I want to see VCP→UFD1 (direct) NOT ATXN3→UFD1 (indirect). Each interaction should be validated in the context of that protein pair only."

**Solution Delivered:**
- ✅ ATXN3→UFD1 validated with ATXN3 as main → NET effects
- ✅ VCP→UFD1 validated with VCP as main → DIRECT effects
- ✅ Both stored in database with clear differentiation
- ✅ Table view shows both rows with visual distinction
- ⏳ Modal and graph need visual implementation (data ready)

**Technical Achievement:**
- Dual validation system with evidence checking
- Canonical ordering preserved
- No data duplication
- Backward compatible with legacy data
- Clean separation of NET vs DIRECT semantics

---

## 🎯 SUCCESS CRITERIA

### Must Have (Definition of Done)
- [x] Backend validates both NET and DIRECT interactions
- [x] Database stores both with function_context differentiation
- [x] Table view shows separate rows with badges
- [ ] Modal shows separate sections for NET and DIRECT
- [ ] Graph shows both links with different styling
- [ ] No visual overlap or glitching
- [ ] All existing functionality still works

### Nice to Have (Future Enhancements)
- [ ] Completeness report (show how many direct links extracted)
- [ ] Evidence quality score for extracted links
- [ ] Option to hide NET effects and show only DIRECT
- [ ] Batch validation mode for all proteins

---

**Memory file created by Claude Code session on 2025-01-17**
**Context: Token usage at 75% when handoff created**
**Remaining work: Modal + Graph rendering (~1.5 hours)**