# Pathway Visualization Fix - December 2025

## Problem Solved
Only 1 root pathway was showing in visualization instead of 10. The hierarchy tree also contained duplicate pathways.

## Root Cause
`build_full_json_from_db()` in app.py (lines 829-944) extracted pathways ONLY from `interaction.data.pathways` (JSONB), NOT from the database Pathway/PathwayParent tables. This meant:
1. Pathways assigned before hierarchy scripts ran were stale
2. The proper hierarchy in Pathway/PathwayParent tables was IGNORED
3. Only pathways embedded in interaction JSONB showed up

## Fixes Applied

### 1. app.py - build_full_json_from_db() (lines 829-997)
**Complete rewrite** of pathway discovery logic:
- Now queries `PathwayInteraction` junction table for pathway-interaction links
- Queries `Pathway` table for all linked pathways PLUS their ancestors
- **Always includes all root pathways** (hierarchy_level=0) regardless of interaction links
- Queries `PathwayParent` for parent-child relationships
- Builds complete hierarchy tree from database, not from stale JSONB

### 2. scripts/pathway_hierarchy/02_build_base_hierarchy.py
Fixed SUB_CATEGORIES to eliminate duplicates:
- DNA Damage Response now only has "DNA Repair" and "DNA Damage Checkpoint" as level 1 children
- "DNA Repair" has "Double-Strand Break Repair", "Nucleotide Excision Repair", etc. as level 2 children
- "Double-Strand Break Repair" has "Homologous Recombination" and "Non-Homologous End Joining" as level 3 children

### 3. scripts/pathway_hierarchy/hierarchy_utils.py - normalize_pathway_name()
Enhanced to handle Greek characters:
- κ → k, β → beta, α → alpha, γ → gamma, δ → delta
- Removes hyphens between alphanumeric chars (NF-kB → NFkB)
- Strips multiple suffixes repeatedly

### 4. NEW: scripts/pathway_hierarchy/07_merge_duplicate_pathways.py
Script to find and merge duplicate pathways based on normalized names:
- Run with `--dry-run` to preview
- Selects canonical pathway (prefers one with ontology_id and more interactions)
- Moves all PathwayInteraction and PathwayParent links to canonical
- Deletes duplicates

## Execution Flow (Fresh Start)

```bash
# 1. Clear pathway tables (keeps proteins and interactions)
python scripts/clear_pathway_tables.py

# 2. Delete cache files (Windows)
del /Q cache\*.json cache\pruned\*.json cache\hierarchy_reports\*

# 3. Start app
python app.py

# 4. Query a protein via web UI (http://localhost:5000)
# Or: curl -X POST http://localhost:5000/api/query -H "Content-Type: application/json" -d "{\"protein\":\"VCP\"}"

# 5. Run hierarchy pipeline
python scripts/pathway_hierarchy/run_all.py

# 6. (Optional) Merge any remaining duplicates
python scripts/pathway_hierarchy/07_merge_duplicate_pathways.py --dry-run
python scripts/pathway_hierarchy/07_merge_duplicate_pathways.py

# 7. View visualization
# http://localhost:5000/api/visualize/VCP
```

## Expected Result
- Console: `🌳 Found 10 root pathways (of N total)`
- Sidebar shows all 10 root categories
- No duplicate pathway names in tree
- Proper hierarchy depth (e.g., DNA Damage Response → DNA Repair → Double-Strand Break Repair → Non-Homologous End Joining)

## Key Files Modified
- `app.py` (lines 829-997)
- `scripts/pathway_hierarchy/02_build_base_hierarchy.py` (SUB_CATEGORIES)
- `scripts/pathway_hierarchy/hierarchy_utils.py` (normalize_pathway_name)
- `scripts/pathway_hierarchy/07_merge_duplicate_pathways.py` (NEW)
