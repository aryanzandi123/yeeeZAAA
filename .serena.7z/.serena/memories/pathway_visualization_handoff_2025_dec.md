# Pathway Visualization Handoff - December 2025

## Quick Start for New Session
```
Activate the current dir as project using serena
Read the memory file pathway_visualization_handoff_2025_dec.md
```

---

## PROJECT CONTEXT

This is a Flask + D3 protein-protein interaction (PPI) visualizer. Users query proteins (e.g., VCP, ATXN3) and see their interactions organized by biological pathways.

**Two-Phase Workflow:**
1. **Query Pipeline** (runner.py): Creates flat pathways when user queries a protein
2. **Hierarchy Pipeline** (scripts/pathway_hierarchy/run_all.py): Organizes pathways into tree structure

---

## FIXES COMPLETED THIS SESSION

### 1. GO ID Bug Fix (CRITICAL - Script 04)
**File:** `scripts/pathway_hierarchy/04_ai_create_missing_branches.py`
**Lines 468-471:** Changed positional args to named params
```python
# BEFORE (broken):
inter_id = create_intermediate_pathway(
    db.session, inter_name, inter_desc, inter_go  # inter_go went to parent_id!
)

# AFTER (fixed):
inter_id = create_intermediate_pathway(
    db.session, inter_name, inter_desc,
    parent_id=prev_id, go_id=inter_go
)
```

**Lines 497-498 and 592-593:** Added `db.session.rollback()` in exception handlers

### 2. Mediator Node Creation (visualizer.js ~line 1161)
**Problem:** "Mediator MDM2 not found in pathway" errors
**Fix:** When mediator not found, create it on-demand instead of skipping

### 3. Hybrid Pathway Expansion (visualizer.js handlePathwayClick)
**Problem:** Either sub-pathways OR interactors shown, never both
**Fix:** Now shows BOTH when expanding a pathway

### 4. Pathway Selector Sidebar (NEW FEATURE)
**Files modified:**
- `visualizer.py` - Added sidebar HTML (lines 96-120)
- `static/viz-styles.css` - Added sidebar CSS (lines 4584-4871)
- `static/visualizer.js` - Added sidebar JS functions (lines 7519-7835)

**Behavior (Option A - Empty Start):**
- Graph starts empty (only main protein node)
- Sidebar lists all root pathways with checkboxes
- User clicks checkboxes to add/remove pathways from graph

---

## CURRENT STATE - NEEDS DEBUGGING

User ran VCP query, then `python scripts/pathway_hierarchy/run_all.py`

**Console Output Issues:**
```
🌳 Found 1 root pathways (of 30 total)  // Only 1 root? Should be more!
📋 Pathway mode: Empty start - use sidebar to select pathways
```

**Potential Issues to Debug:**
1. Only 1 pathway has `hierarchy_level=0` in database - Scripts 02-04 may not be setting levels correctly
2. Sidebar may be empty or not showing all pathways
3. Need to verify pathway hierarchy was built correctly by run_all.py

---

## KEY FILES

| File | Purpose |
|------|---------|
| `static/visualizer.js` | D3 visualization, sidebar logic |
| `visualizer.py` | HTML template with sidebar |
| `static/viz-styles.css` | Sidebar styling |
| `scripts/pathway_hierarchy/run_all.py` | Runs all hierarchy scripts |
| `scripts/pathway_hierarchy/04_ai_create_missing_branches.py` | GO ID bug was here |
| `app.py` | Flask routes, builds pathway JSON |

---

## HOW TO TEST

```bash
# 1. Clear pathway tables (if needed)
python scripts/clear_pathway_tables.py

# 2. Query a protein (via web UI or)
curl -X POST http://localhost:5000/api/query -H "Content-Type: application/json" -d '{"protein":"VCP"}'

# 3. Run hierarchy pipeline
python scripts/pathway_hierarchy/run_all.py

# 4. View visualization
http://localhost:5000/api/visualize/VCP
```

---

## DATABASE SCHEMA REMINDER

```sql
pathways.id              -- INTEGER PRIMARY KEY (auto-increment)
pathways.name            -- VARCHAR (e.g., "Histone Deacetylation")
pathways.ontology_id     -- VARCHAR (e.g., "GO:0035556") - NOT THE SAME AS id!
pathways.hierarchy_level -- INTEGER (0=root, 1, 2, 3...)
pathways.is_leaf         -- BOOLEAN

pathway_parents.child_pathway_id   -- INTEGER FK
pathway_parents.parent_pathway_id  -- INTEGER FK
```

---

## ROOT_CATEGORIES (10 valid roots at level 0)

```
Cellular Signaling, Metabolism, Protein Quality Control, Cell Death,
Cell Cycle, DNA Damage Response, Vesicle Transport, Immune Response,
Neuronal Function, Cytoskeleton Organization
```

---

## SIDEBAR FUNCTIONS (visualizer.js)

- `togglePathwaySidebar()` - collapse/expand sidebar
- `filterPathwaySidebar(searchTerm)` - filter by name
- `selectAllRootPathways()` - add all to graph
- `clearAllRootPathways()` - remove all from graph
- `toggleRootPathway(pathwayId, checkbox)` - toggle single pathway
- `addRootPathwayToGraph(pw)` - create pathway node
- `removeRootPathwayFromGraph(pathwayId)` - remove pathway node
- `initPathwaySidebar()` - builds tree HTML

---

## DEBUGGING STEPS FOR NEXT SESSION

1. Check if sidebar is appearing: F12 console, look for "📋 Sidebar initialized"
2. Check pathway hierarchy_level in database:
   ```python
   from app import app, db
   from models import Pathway
   with app.app_context():
       for p in db.session.query(Pathway).order_by(Pathway.hierarchy_level).all():
           print(f'L{p.hierarchy_level}: {p.name}')
   ```
3. If only 1 root pathway, check if run_all.py completed successfully
4. Look for errors in run_all.py output - particularly Step 4

---

## RELATED MEMORY FILES

- `pathway_hierarchy_fix_session.md` - Previous session context
- `pathway_hierarchy_fix_complete.md` - Earlier fix documentation
