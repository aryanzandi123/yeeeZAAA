# Hierarchical Pathway Frontend Implementation - Complete

## Date: January 2025

## Summary
Implemented hierarchical pathway visualization for the ProPaths PPI visualizer. Users can now expand pathways level-by-level to reveal sub-pathways until reaching leaf pathways with interactors.

## Changes Made

### Backend (app.py)

1. **Modified `build_full_json_from_db()`** (lines 868-928):
   - Added hierarchy enrichment after pathway grouping
   - Queries `Pathway` table for hierarchy fields (hierarchy_level, is_leaf, protein_count, ancestor_ids)
   - Queries `PathwayParent` table to build parent/child relationships
   - Enriches pathway objects with: hierarchy_level, is_leaf, protein_count, ancestry (array), parent_pathway_ids, child_pathway_ids

2. **Added `/api/pathway/<pathway_id>/interactors` endpoint** (lines 1119-1177):
   - Lazy-loads interactors for leaf pathways
   - Returns: pathway_id, pathway_name, hierarchy_level, is_leaf, interactors array

### Frontend (visualizer.js)

1. **State Variables** (lines 33-52):
   - `pathwayHierarchy`: Map storing hierarchy info per pathway
   - `expandedHierarchyPathways`: Set tracking expanded sub-pathways
   - `pathwayToChildren`: Map for parent→children lookup
   - `allPathwaysData`: Array storing all pathway data
   - `PATHWAY_SIZES`: Level-based sizing (50→35px radius)
   - `PATHWAY_COLORS`: Level-based colors (#7c3aed→#c4b5fd)

2. **Initialization** (lines 574-651):
   - Builds hierarchy maps from pathway data
   - Only shows root-level pathways (hierarchy_level === 0) initially

3. **Click Handler** (lines 990-1022):
   - Checks for reference nodes (DAG handling)
   - Prioritizes hierarchy expansion over interactor expansion
   - Routes to `expandPathwayHierarchy()`, `collapsePathwayHierarchy()`, or `expandPathwayWithLazyLoad()`

4. **New Functions**:
   - `expandPathwayHierarchy()`: Creates child pathway nodes with reference node support
   - `collapsePathwayHierarchy()`: Recursively removes descendants
   - `expandPathwayWithLazyLoad()`: Fetches interactors via API for leaf pathways
   - `findExistingPathwayNode()`: Finds existing pathway by originalId
   - `pulseAndCenter()`: Animates and centers view on a node
   - `showAncestryTooltip()` / `hideAncestryTooltip()`: Breadcrumb tooltip

5. **Rendering** (lines 1613-1761):
   - Level-based sizing and stroke colors
   - Expand indicator (+/−) for non-leaf pathways
   - Reference node styling (dashed, with ↗ icon)
   - Ancestry tooltip on hover
   - Loading indicator

### CSS (viz-styles.css, lines 1564-1709)

- Level-based stroke colors (`.pathway-node.level-0` through `.level-3`)
- Hierarchy expanded state
- Reference node styling (dashed border, opacity)
- Hierarchy link styles (dashed)
- Loading animation (`@keyframes pulse-loading`)
- Pulse highlight animation for reference navigation
- Ancestry tooltip styling
- Dark mode adjustments

## Design Decisions

1. **Interactors only at leaf level**: Cleaner UX, simpler logic
2. **Reference nodes for DAG**: Avoids duplicates, clicking navigates to primary
3. **Hybrid data loading**: Metadata upfront, interactors lazy-loaded

## Testing Checklist

- [ ] Root pathways display initially
- [ ] Click root → shows sub-pathways
- [ ] Click sub-pathway → shows deeper levels
- [ ] Click leaf → lazy-loads and shows interactors
- [ ] Collapse works at each level
- [ ] Ancestry tooltip shows on hover
- [ ] Reference nodes navigate to primary
- [ ] Loading indicator appears during API calls
