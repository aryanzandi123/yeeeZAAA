# Pathway Hierarchy Fix Session - Continuation Point

## Problem Being Solved

Three bugs in the pathway hierarchy system:

1. **Hierarchy Bug**: AI-created pathways appearing as ROOT (level 0) instead of properly nested
2. **Function Pathway Mismatch**: Modal showing different pathway than interaction's assigned pathway  
3. **Incomplete Coverage**: Not all interactions have proper deep hierarchies

## Solution Implemented (Option B - hierarchy_chain approach)

All pathways must have a FULL `hierarchy_chain` from ROOT to LEAF, e.g.:
```
["Cellular Signaling", "Transcription", "Epigenetic Regulation", "Histone Deacetylation"]
```

### ROOT_CATEGORIES (10 valid roots at level 0):
- Cellular Signaling
- Metabolism
- Protein Quality Control
- Cell Death
- Cell Cycle
- DNA Damage Response
- Vesicle Transport
- Immune Response
- Neuronal Function
- Cytoskeleton Organization

---

## Files Modified

### 1. `scripts/pathway_hierarchy/ai_hierarchy_builder.py`

**Changes made:**
- Updated `CLASSIFY_PATHWAYS_PROMPT` to require `hierarchy_chain` array in response
- Updated `classify_pathways_batch()` to parse and validate `hierarchy_chain`
- Updated `ASSIGN_INTERACTIONS_PROMPT` for hierarchy_chain format
- Updated `assign_interactions_batch()` for hierarchy_chain validation
- Updated `HANDLE_ORPHAN_PROMPT` to return `hierarchy_chain` for orphans
- Updated `handle_orphan_pathways()` to validate and fix chains
- All functions now validate ROOT_CATEGORIES and auto-prepend "Cellular Signaling" if invalid

### 2. `scripts/pathway_hierarchy/04_ai_create_missing_branches.py`

**Changes made:**
- Added `ensure_hierarchy_chain()` function (KEY FUNCTION) - creates all pathways in chain with proper parent-child links
- Updated `create_intermediate_pathway()` to accept explicit `hierarchy_level` parameter
- Phase 4 (orphan handling) now uses `hierarchy_chain` from AI response
- Calls `ensure_hierarchy_chain()` for each orphan solution

### 3. `scripts/pathway_hierarchy/03_classify_existing_pathways.py`

**Changes made:**
- Added `ensure_hierarchy_chain_local()` - local copy to avoid circular imports
- Added `ROOT_CATEGORIES` constant
- Updated `process_ai_classification_batch()` to use `hierarchy_chain`
- Phase 3 now creates full chains via `ensure_hierarchy_chain_local()`

### 4. `scripts/pathway_hierarchy/05_assign_interactions_to_leaves.py`

**Changes made:**
- Added function pathway sync logic
- After assigning interactions to leaf pathways, syncs the pathway info to each function in the interaction's data JSONB

### 5. `scripts/clear_pathway_tables.py` (NEW FILE)

**Created utility script with:**
- `clear_pathway_tables()` - clears pathway_parents, pathway_interactions, pathways
- `clear_all_tables()` - nuclear option, clears everything including proteins/interactions
- `--dry-run` option to preview
- `--all` option for nuclear clear

---

## Bug FIXED (2025-12-04)

### Root Cause Found
At lines 468-470, positional arguments were in wrong order:
```python
# BROKEN: inter_go (GO ID string) went to parent_id parameter
inter_id = create_intermediate_pathway(
    db.session, inter_name, inter_desc, inter_go
)
```

### Fix Applied
```python
# FIXED: Use named parameters
inter_id = create_intermediate_pathway(
    db.session, inter_name, inter_desc,
    parent_id=prev_id, go_id=inter_go
)
```

### Additional Fixes
Added `db.session.rollback()` in exception handlers (lines 497-498, 592-593) to prevent cascading transaction errors.

---

## Workflow for Testing

1. Clear pathway tables:
   ```bash
   python scripts/clear_pathway_tables.py
   ```

2. Run hierarchy pipeline:
   ```bash
   python scripts/pathway_hierarchy/run_all.py
   ```

3. Check reports:
   ```bash
   cat cache/hierarchy_reports/pathway_tree.md
   ```

4. Verify in visualizer:
   ```
   http://localhost:5000/api/visualize/ATXN3
   ```

---

## Two Pipeline System

1. **Query Pipeline** (runner.py Step 5.5 via `utils/pathway_assigner.py`):
   - Runs when user queries a protein
   - Assigns FLAT pathways to functions (just names, no hierarchy)
   - Uses ONTOLOGY_MAPPINGS with GO IDs and KEGG IDs

2. **Hierarchy Pipeline** (scripts/pathway_hierarchy/run_all.py):
   - Runs separately after queries
   - Builds proper tree structure with parent-child links
   - Sets `hierarchy_level` and `is_leaf` correctly
   - Syncs pathway info back to function JSONB

---

## Key Database Schema

```sql
-- Pathway table
pathways.id           -- INTEGER PRIMARY KEY (auto-increment)
pathways.name         -- VARCHAR (e.g., "Histone Deacetylation")
pathways.ontology_id  -- VARCHAR (e.g., "GO:0035556") - NOT THE SAME AS id!
pathways.hierarchy_level -- INTEGER (0=root, 1, 2, 3...)
pathways.is_leaf      -- BOOLEAN

-- PathwayParent table (parent-child links)
pathway_parents.child_pathway_id   -- INTEGER FK
pathway_parents.parent_pathway_id  -- INTEGER FK
pathway_parents.relationship_type  -- VARCHAR (e.g., "is_a")
pathway_parents.confidence         -- FLOAT
```

---

## Debug Commands

Check hierarchy structure:
```bash
python -c "
import sys; sys.path.insert(0, '.')
from app import app, db
from models import Pathway
with app.app_context():
    for p in db.session.query(Pathway).order_by(Pathway.hierarchy_level).limit(20).all():
        print(f'L{p.hierarchy_level}: {p.name} (id={p.id}, ontology_id={p.ontology_id})')
"
```

---

## Visualization Fixes Applied (2025-12-04)

### Fix 1: Pathway Selector Sidebar (Option A - Empty Start)
- Added sidebar HTML to `visualizer.py`
- Added sidebar CSS to `static/viz-styles.css`  
- Added JavaScript functions to `static/visualizer.js`
- User controls which root pathways appear via checkboxes
- Initially empty graph, user selects pathways to display

### Fix 2: Hybrid Pathway Expansion
- Modified `handlePathwayClick()` in visualizer.js
- Now shows BOTH sub-pathways AND interactors when expanding (no longer either/or)

### Fix 3: Mediator Node Creation On-Demand
- Fixed in `expandPathway()` function
- When mediator nodes not found, they are created dynamically
- Prevents "Mediator MDM2 not found" errors

### Fix 4: Root Display Integrated with Sidebar
- `buildInitialGraph()` no longer creates pathway nodes automatically
- Sidebar controls visibility via `addRootPathwayToGraph()` and `removeRootPathwayFromGraph()`
