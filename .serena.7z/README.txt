python scripts/fix_direct_link_arrows.py --apply
python scripts/validate_existing_arrows.py --verbose
